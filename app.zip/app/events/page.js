'use client';
import { useState, useEffect } from 'react';

export default function EventsPage() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/events')
      .then((res) => res.json())
      .then((data) => setEvents(data));
  }, []);

  const handleRegister = async (eventId) => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      alert('Please login first!');
      return;
    }
    const res = await fetch('http://localhost:5000/event/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: user._id, event_id: eventId }),
    });
    const data = await res.json();
    alert(data.message);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Available Events</h1>

      {events.length === 0 ? (
        <p className="text-center text-gray-500">No events found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {events.map((event) => (
            <div key={event._id} className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold mb-2">{event.name}</h2>
              <p className="text-gray-500 mb-1">📅 {event.date}</p>
              <p className="text-gray-500 mb-1">📍 {event.location}</p>
              <p className="text-gray-500 mb-4">🪑 Seats Left: {event.seats}</p>
              <button
                onClick={() => handleRegister(event._id)}
                className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
              >
                Register for Event
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}