'use client';
import { useState, useEffect } from 'react';

export default function MyRegistrationsPage() {
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      alert('Please login first!');
      return;
    }

    fetch(`http://localhost:5000/registrations/${user._id}`)
      .then((res) => res.json())
      .then(async (data) => {
        const eventDetails = await Promise.all(
          data.map(async (reg) => {
            const res = await fetch(`http://localhost:5000/events`);
            const events = await res.json();
            return events.find((e) => e._id === reg.event_id);
          })
        );
        setRegistrations(eventDetails.filter(Boolean));
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">My Registrations</h1>

      {loading ? (
        <p className="text-center text-gray-500">Loading...</p>
      ) : registrations.length === 0 ? (
        <p className="text-center text-gray-500">You have not registered for any events yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {registrations.map((event, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold mb-2">{event.name}</h2>
              <p className="text-gray-500 mb-1">📅 {event.date}</p>
              <p className="text-gray-500 mb-1">📍 {event.location}</p>
              <p className="text-gray-500 mb-4">🪑 Seats: {event.seats}</p>
              <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm">
                ✅ Registered
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="text-center mt-8">
        <a href="/events" className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600">
          Browse More Events
        </a>
      </div>
    </div>
)}