'use client';
import { useState, useEffect } from 'react';

export default function AdminPage() {
  const [events, setEvents] = useState([]);
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [seats, setSeats] = useState('');
  const [message, setMessage] = useState('');

  const fetchEvents = () => {
    fetch('http://localhost:5000/events')
      .then((res) => res.json())
      .then((data) => setEvents(data));
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const handleCreate = async () => {
    const res = await fetch('http://localhost:5000/event/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, date, location, seats: parseInt(seats) }),
    });
    const data = await res.json();
    setMessage(data.message);
    setName(''); setDate(''); setLocation(''); setSeats('');
    fetchEvents();
  };

  const handleDelete = async (eventId) => {
    await fetch(`http://localhost:5000/event/delete/${eventId}`, {
      method: 'DELETE',
    });
    fetchEvents();
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Admin Dashboard</h1>

      {/* Create Event Form */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-8 max-w-lg mx-auto">
        <h2 className="text-xl font-bold mb-4">Create New Event</h2>

        <input type="text" placeholder="Event Name"
          className="w-full border p-2 rounded mb-3"
          value={name} onChange={(e) => setName(e.target.value)} />

        <input type="date"
          className="w-full border p-2 rounded mb-3"
          value={date} onChange={(e) => setDate(e.target.value)} />

        <input type="text" placeholder="Location"
          className="w-full border p-2 rounded mb-3"
          value={location} onChange={(e) => setLocation(e.target.value)} />

        <input type="number" placeholder="Total Seats"
          className="w-full border p-2 rounded mb-3"
          value={seats} onChange={(e) => setSeats(e.target.value)} />

        <button onClick={handleCreate}
          className="w-full bg-green-500 text-white p-2 rounded hover:bg-green-600">
          Create Event
        </button>

        {message && <p className="text-center mt-3 text-green-600">{message}</p>}
      </div>

      {/* Events List */}
      <h2 className="text-2xl font-bold text-center mb-4">All Events</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {events.map((event) => (
          <div key={event._id} className="bg-white rounded-xl shadow-md p-6">
            <h2 className="text-xl font-bold mb-2">{event.name}</h2>
            <p className="text-gray-500 mb-1">📅 {event.date}</p>
            <p className="text-gray-500 mb-1">📍 {event.location}</p>
            <p className="text-gray-500 mb-4">🪑 Seats: {event.seats}</p>
            <button onClick={() => handleDelete(event._id)}
              className="w-full bg-red-500 text-white p-2 rounded hover:bg-red-600">
              Delete Event
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}